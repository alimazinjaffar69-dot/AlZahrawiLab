<?php
declare(strict_types=1);

const DB_HOST = '127.0.0.1';
const DB_NAME = 'alzahrawi_lab';
const DB_USER = 'root';
const DB_PASS = '';

const APP_TIMEZONE = 'Asia/Baghdad';
const UPLOAD_DIR = __DIR__ . '/uploads/results';
const MAX_PDF_BYTES = 10485760; // 10 MB

// Change this before using Base outside your computer.
const BASE_API_KEY = 'change-this-base-secret-key';

const ALLOWED_ORIGINS = [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    'http://localhost',
    'http://127.0.0.1',
];

date_default_timezone_set(APP_TIMEZONE);
